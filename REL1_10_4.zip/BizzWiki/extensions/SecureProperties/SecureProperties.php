<?php
/*<wikitext>
{| border=1
| <b>File</b> || SecureProperties.php
|-
| <b>Revision</b> || $Id: SecureProperties.php 258 2007-07-02 20:51:56Z jeanlou.dupont $
|-
| <b>Author</b> || Jean-Lou Dupont
|}<br/><br/>
 
== Purpose==
Enables getting/setting global object properties securily (operations are only allowed on protected pages).

== Usage ==
* Property 'get': <nowiki>{{#pg:global object name|property}}</nowiki>
* Property 'set': <nowiki>{{#ps:global object name|property|value}}</nowiki>

== Examples ==
Current user name: {{#pg:wgUser|mName}}

Current user id: {{#pg:wgUser|mId}}

== Features ==
* Security: the 'magic words' of the extension can only be used on protected pages

== Dependancy ==
* ExtensionClass extension

== Installation ==
To install independantly from BizzWiki:
* Download 'ExtensionClass' extension
* Apply the following changes to 'LocalSettings.php'
<geshi lang=php>
require('extensions/ExtensionClass.php');
require('extensions/SecureProperties/SecureProperties.php');
</geshi>

== History ==

== Code ==
</wikitext>*/
// Verify if 'ExtensionClass' is present.
if ( !class_exists('ExtensionClass') )
	echo 'ExtensionClass missing: SecureProperties extension will not work!';	
else
{
	require( "SecurePropertiesClass.php" );
	SecurePropertiesClass::singleton();
}
?>