<?php
/*<wikitext>
{| border=1
| <b>File</b> || SimpleReplicator.php
|-
| <b>Revision</b> || $Id: SimpleReplicator.php 423 2007-07-20 01:15:05Z jeanlou.dupont $
|-
| <b>Author</b> || Jean-Lou Dupont
|}<br/><br/>
 
== Purpose==


== Features ==


== Dependancy ==
* StubManager Extension

== History ==

== Code ==
</wikitext>*/

require('PartnerMachine.php');
require('PartnerObject.php');
require('PartnerJob.php');

// Stub required for logging & job functionality.
$wgAutoloadClasses['FetchPartnerRCjob'] = dirname(__FILE__).'/PartnerRC/FetchPartnerRCjob.php';

StubManager::createStub(	'FetchPartnerRC', 
							dirname(__FILE__).'/PartnerRC/FetchPartnerRC.php',
							dirname(__FILE__).'/PartnerRC/FetchPartnerRC.i18n.php',
							array('SpecialVersionExtensionTypes'),
							true // logging included
						 );

$wgAutoloadClasses['FetchPartnerLogJob'] = dirname(__FILE__).'/PartnerLog/FetchPartnerLogJob.php';
StubManager::createStub(	'FetchPartnerLog', 
							dirname(__FILE__).'/PartnerLog/FetchPartnerLog.php',
							dirname(__FILE__).'/PartnerLog/FetchPartnerLog.i18n.php',
							array('SpecialVersionExtensionTypes'),
							true // logging included
						 );


?>