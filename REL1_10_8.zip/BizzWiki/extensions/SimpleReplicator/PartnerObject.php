<?php
/*<wikitext>
{| border=1
| <b>File</b> || PartnerObject.php
|-
| <b>Revision</b> || $Id: PartnerObject.php 417 2007-07-19 16:00:58Z jeanlou.dupont $
|-
| <b>Author</b> || Jean-Lou Dupont
|}<br/><br/>
 
== Purpose==


== Features ==


== Dependancy ==
* [[Extension:ExtensionClass|ExtensionClass]]
* PartnerMachine class
* TableClass class

== History ==

== Code ==
</wikitext>*/
$wgAutoloadClasses['TableClass'] 		= dirname(__FILE__).'/TableClass.php';
$wgAutoloadClasses['PartnerObjectClass']= dirname(__FILE__).'/PartnerObjectClass.php';
?>