<?php
/**
 * Internationalisation file for FileManager extension.
 *
 * $Id: FileManager.i18n.php 422 2007-07-20 00:22:33Z jeanlou.dupont $
 * 
*/

$wgFileManagerLogMessages = array();

$wgFileManagerLogMessages['en'] = array(
	'commitfil'.'logpage'               => 'Commit File log',
	'commitfil'.'logpagetext'           => 'This is a log of <i>file commit</i> actions',
	'commitfil'.'logentry'              => '',
	'commitfil'.'-commitok-entry'    => 'File successfully committed to filesystem',
	'commitfil'.'-commitfail-entry'  => 'File commit to filesystem <b>failed</b>',
	'commitfil'.'-commit-text'       => "[[$1:$2|$2]]",
	'filemanager-script-exists'       => 'File <b>$1</b> exists',
	'filemanager-script-notexists'    => 'File <b>$1</b> does not exist',	
	#'' => '',
);
?>