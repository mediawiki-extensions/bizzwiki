<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#0033cc" COLOR="#ffffff" CREATED="1181865173781" ID="Freemind_Link_39388484" MODIFIED="1181954009671" TEXT="SuperGroups">
<icon BUILTIN="password"/>
<hook NAME="accessories/plugins/NodeNote.properties">
<text>$Id: SuperGroups.mm 192 2007-06-19 01:27:56Z jeanlou.dupont $</text>
</hook>
<node CREATED="1181865199343" ID="_" MODIFIED="1181865203156" POSITION="right" TEXT="Use Cases">
<node CREATED="1181865354312" HGAP="42" ID="Freemind_Link_718462489" MODIFIED="1181865374937" TEXT="Create a SGI" VSHIFT="-44">
<node CREATED="1181865627921" HGAP="32" ID="Freemind_Link_1916255713" MODIFIED="1181865674421" TEXT="Authorization Process"/>
</node>
<node CREATED="1181865376312" HGAP="47" ID="Freemind_Link_918959068" MODIFIED="1181865384781" TEXT="Delete a SGI" VSHIFT="-19">
<node CREATED="1181865627921" HGAP="33" ID="Freemind_Link_1451318345" MODIFIED="1181865676546" TEXT="Authorization Process" VSHIFT="-1"/>
</node>
<node CREATED="1181865204593" HGAP="38" ID="Freemind_Link_1213158629" MODIFIED="1181865369375" TEXT="Add User to SGI" VSHIFT="-46">
<node CREATED="1181865627921" ID="Freemind_Link_999819745" MODIFIED="1181865635750" TEXT="Authorization Process"/>
</node>
<node CREATED="1181865224250" HGAP="34" ID="Freemind_Link_1309114088" MODIFIED="1181865371125" TEXT="Delete User from SGI" VSHIFT="-2">
<node CREATED="1181865627921" ID="Freemind_Link_1881662455" MODIFIED="1181865635750" TEXT="Authorization Process"/>
</node>
<node CREATED="1182131297984" HGAP="32" ID="Freemind_Link_584491322" MODIFIED="1182131317328" TEXT="User X delegates rights R to User Y" VSHIFT="14">
<node CREATED="1182216336453" ID="Freemind_Link_843492026" MODIFIED="1182216346125" TEXT="Delegatable Rights"/>
<node CREATED="1182216347109" ID="Freemind_Link_1378662927" MODIFIED="1182216354531" TEXT="Non-delagatable Rights"/>
</node>
</node>
<node CREATED="1181865705859" HGAP="29" ID="Freemind_Link_294030713" MODIFIED="1181865729656" POSITION="left" TEXT="SuperGroup Instance (SGI)" VSHIFT="18">
<node CREATED="1181865718375" HGAP="29" ID="Freemind_Link_65824334" MODIFIED="1181865727187" TEXT="User List" VSHIFT="17"/>
<node CREATED="1182216385859" ID="Freemind_Link_1143833088" MODIFIED="1182216388812" TEXT="Segregation"/>
</node>
<node CREATED="1182131284046" HGAP="33" ID="Freemind_Link_10150872" MODIFIED="1182131290859" POSITION="right" TEXT="Delegation" VSHIFT="45">
<node CREATED="1182131406546" ID="Freemind_Link_1561150027" MODIFIED="1182131416109" TEXT="Sub-space"/>
<node CREATED="1182131417515" ID="Freemind_Link_1308722532" MODIFIED="1182131419500" TEXT="Rights"/>
</node>
</node>
</map>
