<?php
/**
 * Internationalisation file for InterWikiLinkManager extension.
 *
 * $Id: InterWikiLinkManager.i18n.php 189 2007-06-17 19:24:24Z jeanlou.dupont $
 * 
*/

?>