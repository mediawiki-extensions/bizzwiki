<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1181953354546" ID="Freemind_Link_1894811961" MODIFIED="1181954446718" TEXT="Addressing">
<hook NAME="accessories/plugins/NodeNote.properties">
<text>$Id: Addressing.mm 180 2007-06-16 00:48:57Z jeanlou.dupont $&#xa;</text>
</hook>
<node CREATED="1181953751171" HGAP="45" ID="_" MODIFIED="1181954460859" POSITION="right" TEXT="DNS" VSHIFT="-76">
<node CREATED="1181954465812" ID="Freemind_Link_1282421958" MODIFIED="1181954492046" TEXT="machine.rgroup.cluster.domain" VSHIFT="-19"/>
</node>
<node CREATED="1181954212875" HGAP="37" ID="Freemind_Link_918826551" MODIFIED="1181954575171" POSITION="left" TEXT="Cluster" VSHIFT="-19"/>
<node CREATED="1181954230312" HGAP="40" ID="Freemind_Link_1683618043" MODIFIED="1181954576968" POSITION="left" TEXT="Replication Group" VSHIFT="-18"/>
<node CREATED="1181954219453" HGAP="52" ID="Freemind_Link_1067610817" MODIFIED="1181954578859" POSITION="left" TEXT="Individual Machine" VSHIFT="10"/>
<node CREATED="1181954384281" HGAP="40" ID="Freemind_Link_1032776967" MODIFIED="1181954586062" POSITION="right" TEXT="Interwiki Links" VSHIFT="21"/>
<node CREATED="1181954589312" HGAP="47" ID="Freemind_Link_1774808769" MODIFIED="1181954596609" POSITION="right" TEXT="Redirect Page" VSHIFT="24"/>
</node>
</map>
