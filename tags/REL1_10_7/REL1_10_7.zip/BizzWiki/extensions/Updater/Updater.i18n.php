<?php
/**
 * Internationalisation file for Updater extension.
 *
 * $Id: Updater.i18n.php 206 2007-06-28 15:04:22Z jeanlou.dupont $
 * 
*/

$wgUpdaterMessages['en'] = array(
	'updater' => 'Updater',
	#'' => '',
);
?>