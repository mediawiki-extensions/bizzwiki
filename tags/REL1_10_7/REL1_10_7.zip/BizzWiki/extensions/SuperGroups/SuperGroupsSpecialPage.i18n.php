<?php
/**
 * Internationalisation file for SuperGroups extension.
 * $Id: SuperGroupsSpecialPage.i18n.php 175 2007-06-16 00:22:09Z jeanlou.dupont $
*/


?>