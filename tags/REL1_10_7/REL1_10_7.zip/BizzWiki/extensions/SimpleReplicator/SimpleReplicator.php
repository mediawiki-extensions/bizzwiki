<?php
/*<wikitext>
{| border=1
| <b>File</b> || SimpleReplicator.php
|-
| <b>Revision</b> || $Id$
|-
| <b>Author</b> || Jean-Lou Dupont
|}<br/><br/>
 
== Purpose==


== Features ==

== Theory of Operation ==

=== Job getPartnerRC ==

=== Job getPartnerPage ===

=== Job getPartnerRevision ===

=== Job getPartnerUser ===



== Dependancy ==

== Installation ==

== History ==

== Code ==
</wikitext>*/
require('SimpleReplicatorClass.php');
?>