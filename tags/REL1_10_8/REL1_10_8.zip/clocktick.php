<?php
/**
	clocktick.php
	@author: Jean-Lou Dupont
	$Id: clocktick.php 418 2007-07-19 18:12:59Z jeanlou.dupont $
	
    Purpose: Execute this script with a cron/shell command to initiate a 'ClockTickEvent' hook chain 
    ======== execution in a Mediawiki installation.
	 
             The main purpose of this script is to provide a regular timebase 
			 for functionality such as 'replication'.
			 
	Security Notes:
	===============
	- Ensure that this script can only be executed locally by effecting the relevant commands
	  in your installation e.g. 'chmod', 'chgrp' and 'chown'
	  
	INSTALLATION NOTES:
	===================
	- Put this script in the root directory of the mediawiki installation
	- Install appropriate rights management (chmod, chgrp, chown)
	- Customization the 'timebase' parameter
	
 */

require_once( './includes/WebStart.php' );

// Customize this entry if you require the logs to appear
// under another user name.
$wgUser = User::newFromName('WikiReplicator');

wfRunHooks('ClockTickEvent', 60 /* timebase in seconds */ );

?>