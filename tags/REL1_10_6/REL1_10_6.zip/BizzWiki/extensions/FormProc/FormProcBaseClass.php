<?php
/*<wikitext>
{| border=1
| <b>File</b> || FormProcBaseClass.php
|-
| <b>Revision</b> || $Id: FormProcBaseClass.php 296 2007-07-05 11:07:20Z jeanlou.dupont $
|-
| <b>Author</b> || Jean-Lou Dupont
|}<br/><br/>
 
== Purpose==
Provides a useful base class for form processing classes.

== Features ==


== History ==

== Code ==
</wikitext>*/

class FormProcBaseClass
{
	
}
?>