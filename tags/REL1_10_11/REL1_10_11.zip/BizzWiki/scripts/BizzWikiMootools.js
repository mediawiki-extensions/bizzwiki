/*<wikitext>
{{Extension
|name        = BizzWikiMootools
|status      = beta
|type        = other
|author      = [[user:jldupont|Jean-Lou Dupont]]
|image       =
|version     = See SVN ($Id: BizzWikiMootools.js 573 2007-08-05 04:48:12Z jeanlou.dupont $)
|update      =
|mediawiki   = tested on 1.10 but probably works with a earlier versions
|download    = [http://bizzwiki.googlecode.com/svn/trunk/BizzWiki/scripts/ SVN]
|readme      =
|changelog   =
|description = 
|parameters  =
|rights      =
|example     =
}}
 
== Purpose==


== Features ==


== Dependancy ==
* [http://mootools.net/ Mootools]

== Installation ==
To install independantly from BizzWiki:

== History ==

== See Also ==
This extension is part of the [[Extension:BizzWiki|BizzWiki Platform]].

== Code ==
</wikitext>*/

// register an 'onload' event 

// process the PageElements list

// register each component with Mootools


