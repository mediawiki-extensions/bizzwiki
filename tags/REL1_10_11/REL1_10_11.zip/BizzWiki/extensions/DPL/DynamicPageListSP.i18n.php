<?php
/**
 * @version 1.1.1
 * @version 1.1.7
 *          changed label for "create report"
 */
$allMessages = array(
        'en' => array( 
                'dynamicpagelistsp' => 'Dynamic Page List',
				'dpl2_createreport' => 'create DPL report', 
          )
);
?>