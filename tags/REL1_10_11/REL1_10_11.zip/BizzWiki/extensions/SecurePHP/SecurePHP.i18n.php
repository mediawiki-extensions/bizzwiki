<?php
/**
 * Internationalisation file for [[Extension:SecurePHP]] extension.
 *
 * $Id: SecurePHP.i18n.php 664 2007-08-15 00:07:21Z jeanlou.dupont $
 * 
*/

SecurePHP::$msg['en'] = array(
	#'' => '',
);