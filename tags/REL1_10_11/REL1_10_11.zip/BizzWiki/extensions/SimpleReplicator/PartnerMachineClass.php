<?php
/*<wikitext>
{| border=1
| <b>File</b> || XYZ.php
|-
| <b>Revision</b> || $Id: PartnerMachineClass.php 413 2007-07-19 13:18:45Z jeanlou.dupont $
|-
| <b>Author</b> || Jean-Lou Dupont
|}<br/><br/>
== Code ==
</wikitext>*/

class PartnerMachine
{
	static $id		= '$Id: PartnerMachineClass.php 413 2007-07-19 13:18:45Z jeanlou.dupont $';
	static $url		= 'http://localhost/wiki';
	static $port	= 80;  						// standard HTTP/TCP port
	static $timeout = 15;						// in seconds

} // end class declaration
?>