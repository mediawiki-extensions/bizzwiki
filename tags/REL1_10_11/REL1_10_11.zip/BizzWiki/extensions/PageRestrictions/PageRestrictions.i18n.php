<?php
/**
 * Internationalisation file for PageRestrictions extension.
 *
 * $Id: PageRestrictions.i18n.php 369 2007-07-12 14:31:10Z jeanlou.dupont $
 * 
*/

PageRestrictionsClass::$msg['en'] = array(
'restriction-read'		=>    'Read',
'restriction-raw' 		=>    'Raw',
'restriction-viewsource'=>    'Viewsource',
#'' => '',
);
?>