<?php
/**
 * Internationalisation file for GoogleCode extension.
 *
 * $Id: GoogleCode.i18n.php 669 2007-08-16 18:56:39Z jeanlou.dupont $
 * 
*/

GoogleCode::$msg = array();

GoogleCode::$msg['en'] = array(
'googlecode'					=> "<b>GoogleCode: </b>",
'googlecode'.'-missing-project'=> 'missing project name',
'googlecode'.'-missing-file' 	=> 'missing file name',
'googlecode'.'-missing-lang' 	=> 'missing language field',
'googlecode'.'-error-accessing-URI'	=> 'error occured whilst accessing Project=$1 File=$2',
#'' => '',
);
