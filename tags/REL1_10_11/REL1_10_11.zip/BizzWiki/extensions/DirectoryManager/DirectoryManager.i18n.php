<?php
/**
 * Internationalisation file for AutoRedirect extension.
 *
 * $Id: DirectoryManager.i18n.php 655 2007-08-13 14:19:30Z jeanlou.dupont $
 * 
*/

DirectoryManager::$msg = array();

DirectoryManager::$msg['en'] = array(
'directorymanager'.'title'	=> 'Directory Manager',
'directorymanager'.'view'	=> 'View directory <i>$1</i>',
'directorymanager'.'-template'=> 
'	<filepattern>[[Filesystem:$1]]</filepattern>
	<dirpattern>{{#directory:$1|$1}}</dirpattern>
	<linepattern>$1<br/></linepattern>

	<b>Directory Listing</b>
<br/>
',
#'directorymanager'.''=> '',
);
